#!/usr/bin/env python3
x = 10
print (type(x))
x = 25.7
print (type(x))
x = "Hello"
print (type(x))
