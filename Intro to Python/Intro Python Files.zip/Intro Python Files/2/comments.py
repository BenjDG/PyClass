#!/usr/bin/env python3
#
#       some comments
#
x = 10                          # an integer
y = "hello there!"              # a string
z = "This # is not a comment "
