#!/usr/bin/env python3
quot = "first name: {0}\nlast name: {1}"
line = quot.format("mike", "smith")
print(line)
 
quot="first name: {first}\nlast name: {last}"
line=quot.format(first="Michael", last="Smith")
print(line)
