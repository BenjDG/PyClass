#!/usr/bin/env python3
x = "www.trainingetc.com"
result = x.startswith("www")
print(result)
print(x.endswith(".org"))
y = x.upper()
print("ORIGINAL", x)
print("RETURNED", y)
