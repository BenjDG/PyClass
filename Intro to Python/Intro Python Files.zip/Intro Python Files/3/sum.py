#!/usr/bin/env python3
""" Add the integers from 1 to 10 """
count = 1
total = 0

while count <= 10:
    total += count
    count += 1

print(total)
