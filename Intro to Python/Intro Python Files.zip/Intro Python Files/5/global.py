#!/usr/bin/env python3
def demo():
    global count
    count = 0

count = 5
print("Before Function:", count)
demo()
print("After Function:", count)
