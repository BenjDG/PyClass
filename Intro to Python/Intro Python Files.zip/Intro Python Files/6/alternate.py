#!/usr/bin/env python3
from reuseable import *

print("Module name is: " + __name__)

a = square(5)
b = cube(5)
print(a, b)
