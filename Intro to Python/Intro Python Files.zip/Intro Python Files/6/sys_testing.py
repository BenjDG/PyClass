#!/usr/bin/env python3
import sys
print("Command Name:", sys.argv[0])
print("Command Line Arguments Are:", sys.argv[1:])
print("sys.maxsize =", sys.maxsize)
print()
print("sys.path =", sys.path)
print()
print("sys.version =", sys.version)
print()
print("Version = ", sys.version.split()[0])
