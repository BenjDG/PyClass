#!/usr/bin/env python3
import sys
ct = 0
allchars = sys.stdin.read()
for i in allchars:
	print(i, end="")
