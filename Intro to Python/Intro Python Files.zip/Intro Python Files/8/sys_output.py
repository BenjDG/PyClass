#!/usr/bin/env python3
import sys

sys.stdout.write("Standard Output\n")
sys.stderr.write("Error Output\n")
