#!/usr/bin/env python3
f = open('output', 'w') 
f.write('This is a test.\n') 
f.write('This is another test.\n') 
f.close()
