#!/usr/bin/env python3
from auto import Auto

a = Auto("Chevy", "Malibu")
print (a.count())
b = Auto("Mazda", "Miata")
print(Auto.howmany)
