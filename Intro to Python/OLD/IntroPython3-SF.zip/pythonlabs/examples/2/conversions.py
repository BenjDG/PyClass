#!/usr/bin/env python3
x = "10"
y = 20
result = int(x) + y + int("30")
print(result)
print("The result is: " + str(result))
a = 23.45
b = "12.34"
print(a + float(b))
print(ord("A"))
print(chr(65))
