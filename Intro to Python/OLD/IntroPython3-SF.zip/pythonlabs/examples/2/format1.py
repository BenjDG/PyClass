#!/usr/bin/env python3
name = "michael"
age = 65
average = 92.65
print("|%s %d %f|" % (name, age, average))
