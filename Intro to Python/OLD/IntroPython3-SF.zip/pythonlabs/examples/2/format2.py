#!/usr/bin/env python3
name = "michael"
age = 65
average = 92.65
print("|%-10s %5d %5.2f|" % (name, age, average + 1))
