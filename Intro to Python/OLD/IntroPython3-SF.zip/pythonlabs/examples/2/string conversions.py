#!/usr/bin/env python3
print("This Is A Sample String".swapcase())
print("ALL To Lower Case".lower())
print("this will be capitalized".capitalize())
print("this will be title case".title())
