#!/usr/bin/env python3
print("AbCDefg".isalpha(), "AbCDe123".isalpha())
print("12345".isnumeric(), "12345BCD".isnumeric())
print("   \t\n".isspace(), "a  b\t\n".isspace())
print("ABCDEFG".isupper(), "abcdefg".isupper())
print("abcdefg".islower(), "ABCDEFG".islower())
