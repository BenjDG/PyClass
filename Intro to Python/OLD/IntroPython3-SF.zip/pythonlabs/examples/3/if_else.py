#!/usr/bin/env python3
x = 0
if x == 10:
    print("x is 10")
else:
    print("x is not 10")

print("done with the if else")
