#!/usr/bin/env python3
x = y = 0
if x == 0 and y == 0:
    print("x and y are zero")

if x == 0 or y == 0:
    print("x or y or both are zero")

if not ( x >= 10 and x <= 20 ):
    print("x not between 10 and 20")
