#!/usr/bin/env python3
counter = 1
total = 0
while counter <= 10:
    total += counter
    counter += 1
else:
    print("Total is:", total)

