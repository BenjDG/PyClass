#!/usr/bin/env python3
def printmsg():
    print("This function simply ", end="")
    print("prints this message")

printmsg()
