#!/usr/bin/env python3
import reuseable

a = reuseable.square(5)
b = reuseable.cube(5)
print(a, b)
