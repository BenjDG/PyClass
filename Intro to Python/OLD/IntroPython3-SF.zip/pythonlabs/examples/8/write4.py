#!/usr/bin/env python3
f = open("numeric", "w")
x = 58
f.write(str(x) + "\n")
f.write(str(43.5))
f.close()
