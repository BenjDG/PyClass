#!/usr/bin/env python3
#
# A Solution For Chapter 1 Exercise 3
#
x = 10
y = 20
x = x + 3
y = y * x
print(x)
print(y)
