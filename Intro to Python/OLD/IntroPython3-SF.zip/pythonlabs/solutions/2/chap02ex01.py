#!/usr/bin/env python3
#
# A Solution For Chapter 2 Exercise 1
#
radius = float(input("enter the radius: "))
area = 3.14159 * radius * radius
print("Area of circle with radius:", radius, "is", area)
