#!/usr/bin/env python3
#
# A Solution For Chapter 2 Exercise 2
#
first = float(input("enter first number: "))
second = float(input("enter second number: "))

product = first * second

print("Product of", first, "and", second, "is", product)
