#!/usr/bin/env python3
#
# A Solution For Chapter 2 Exercise 3
#
string = input("enter a string: ")
number = int(input("enter a replication factor: "))

repeat = string * number

print(string, "repeated", number, "times is:", repeat)
