#!/usr/bin/env python3
#
# A Solution For Chapter 2 Exercise 4
#
base = float(input("enter a base: "))
expo = float(input("enter an exponent: "))

power = base ** expo

print(base, "to the", expo, "power is", power)
