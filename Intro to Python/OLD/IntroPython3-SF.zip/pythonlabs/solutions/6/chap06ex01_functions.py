#!/usr/bin/python
#
# Part 1 of a  Solution For Chapter 6 Exercise 1
#
def one():
    print("one")

def two():
    print("two")
