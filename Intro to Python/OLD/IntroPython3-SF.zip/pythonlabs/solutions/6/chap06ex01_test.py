#!/usr/bin/python
#
# Part 2 of a  Solution For Chapter 6 Exercise 1
#
from chap06ex02_functions import *

one()
two()
