#!/usr/bin/python
#
# A Solution For Chapter 6 Exercise 2
#
import chap06ex01_functions
def one():
    print("One From Exercise 2 module")

one()
chap06ex01_functions.one()

