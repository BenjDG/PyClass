#!/usr/bin/python
#
# A Solution For Chapter 6 Exercise 3
#
from sys import argv

argv.pop(0)
argv.sort()
print(argv)
